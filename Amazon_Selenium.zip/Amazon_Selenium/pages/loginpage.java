package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class loginpage {

	 WebDriver driver; 
	
	By entermobilenumber = By.id("ap_email");
	By Continue = By.id("continue");
	By createyouramazonaccount = By.id("createAccountSubmit");
	By otp = By.id("continue");
	By enterotp = By.id("cvf-page-content");
	By login = By.id("continue");
	 By sigin = By.id("a-autoid-0-announce");
	 By createamaze = By.id("createAccountSubmit");
	 By mob = By.id("ap_phone_number");
	 By pass = By.id("ap_password");
	 By name = By.id("ap_customer_name");
	 By siginsub = By.id("signInSubmit");
	 By navclick  = By.xpath("//*[@id='nav-search-submit-text']");
	 By searching = By.id("twotabsearchtextbox");
	 By out = By.xpath("//*[@id='nav-item-signout']");

	
public loginpage (WebDriver driver)
	
	{
	 this.driver=driver;
	} 
 
public void entrmobilenum(String p) {
	
	 driver.findElement(entermobilenumber).sendKeys(p);
	 	
	}

public void signinn() {
	
	 driver.findElement(siginsub).click();
	 	
	}


public void mobilenum(String strmobilenum) {
	
 driver.findElement(mob).sendKeys(strmobilenum);
 	
}

public void password (String strmobilenum) {
	
	 driver.findElement(pass).sendKeys(strmobilenum);
	 	
	}

public void Name (String strmobilenum) {
	
	 driver.findElement(name).sendKeys(strmobilenum);
	 	
	}


public void Continuebutton()

{
	driver.findElement(Continue).click();
}

public void Createanaccount() {
	
	driver.findElement(createyouramazonaccount).click();
}

public void loginusingotp()

{
	driver.findElement(otp).click();
}

public void enterotp ()

{
	driver.findElement(otp).click();
	
}

public  void signinsecure()

{
	driver.findElement(sigin).click();
}

public  void createamazon()

{
	driver.findElement(createamaze).click();
}

public  void cont()

{
	driver.findElement(By.id("continue")).click();
	
}

public void signout() {
	
	driver.findElement(out).click();
}


public void search(String k) {
	
	driver.findElement(searching).sendKeys(k);
}

public void searchclick() {
	
	driver.findElement(navclick).click();
}


}
	


