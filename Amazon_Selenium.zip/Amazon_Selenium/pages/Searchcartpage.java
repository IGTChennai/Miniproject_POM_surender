package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Searchcartpage {

WebDriver driver;
By searching = By.id("twotabsearchtextbox");
By navclick = By.id("nav-search-submit-text");
By cartt = By.id("nav-cart-count");
By proceed = By.id("sc-buy-box-ptc-button");
By check = By.id("sc-item-Ca1275a22-668d-42f9-9ae2-d1809cef4899");


public Searchcartpage(WebDriver driver) {

	this.driver = driver;
}

public void search(String k) {
	
	driver.findElement(searching).sendKeys(k);
}

public void searchclick() {
	
	driver.findElement(navclick).click();
}

public void cart()

{
driver.findElement(cartt).click();
}

public void proceedtobuy()

{
driver.findElement(proceed).click();
}

public void checkbox()

{
driver.findElement(check).click();
}

}


