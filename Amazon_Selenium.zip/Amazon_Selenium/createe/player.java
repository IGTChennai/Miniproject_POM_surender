package createe;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class player {

	public void create() throws InterruptedException
	
	{
		System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://xxmsl087/navigator/#/login");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//*[@id='auth-login-page-button']/span")).click();
		driver.findElement(By.xpath("//*[@id='login_username']")).sendKeys("administrator");
		driver.findElement(By.xpath("//*[@id='login_password']")).sendKeys("welcome");
		driver.findElement(By.id("auth-login-page-button")).click();
		driver.findElement(By.id("es-main-menu-button")).click();
		driver.findElement(By.id("side-menu-button-8000")).click();
		driver.findElement(By.xpath("//*[@id='side-menu-button-8010']")).click();

	}
	
	public static void main(String[] args) throws InterruptedException {
		
		player a = new player();
		a.create();

	}

}
