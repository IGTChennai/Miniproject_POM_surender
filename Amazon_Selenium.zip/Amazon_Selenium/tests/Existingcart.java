package tests;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import pages.Searchcartpage;
import pages.loginpage;

public class Existingcart {
	
	public static void main(String[] args) throws InterruptedException {
       System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
		Thread.sleep(5000);	
		loginpage log = PageFactory.initElements(driver,loginpage.class);
		Searchcartpage sear = PageFactory.initElements(driver,Searchcartpage.class);
		log.signinsecure();
		log.entrmobilenum("surendarkrish10@gmail.com");
		log.cont();
		log.password("Suren10@@@");
		log.signinn();
		sear.cart();
		String n = driver.findElement(By.id("sc-active-cart")).getText();
        System.out.println(n);
        Select dropdown = new Select(driver.findElement(By.name("quantity")));
        dropdown.selectByValue("3");
        driver.findElement(By.id("sc-item-Ca1275a22-668d-42f9-9ae2-d1809cef4899")).click();
        System.out.println("the checkbox is selected" +driver.findElement(By.id("sc-item-Ca1275a22-668d-42f9-9ae2-d1809cef4899")).isSelected());
        System.out.println("the checkbox is enabled" + driver.findElement(By.id("sc-item-Ca1275a22-668d-42f9-9ae2-d1809cef4899")).isEnabled());
        System.out.println("the checkbox is displayed" + driver.findElement(By.id("sc-item-Ca1275a22-668d-42f9-9ae2-d1809cef4899")).isDisplayed());
        System.out.println("The giftbox checbox is clicked");
       Thread.sleep(7000);
        sear.proceedtobuy();
        System.out.println("The payment page is displayed");
       
	}

}
