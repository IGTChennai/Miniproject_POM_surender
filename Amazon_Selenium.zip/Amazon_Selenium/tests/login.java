package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import pages.loginpage;



public class login {
	
	
public void blankvalues() throws InterruptedException

{
	System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.get("https://www.amazon.in/");
	driver.manage().window().maximize();
	Thread.sleep(5000);	
	loginpage log = PageFactory.initElements(driver,loginpage.class);
	log.signinsecure();
	log.cont();
	String connn = driver.findElement(By.id("auth-email-missing-alert")).getText();
	System.out.println(connn);
	
}

public void invalidvalues() throws InterruptedException

{
	System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.get("https://www.amazon.in/");
	driver.manage().window().maximize();
	Thread.sleep(5000);	
	loginpage log = PageFactory.initElements(driver,loginpage.class);
	log.signinsecure();
	log.entrmobilenum("invalid");
	log.cont();
	String connn = driver.findElement(By.id("auth-error-message-box")).getText();
	System.out.println(connn);
	
}

public void loginsuccessful() throws InterruptedException

{
	System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.get("https://www.amazon.in/");
	driver.manage().window().maximize();
	Thread.sleep(5000);	
	loginpage log = PageFactory.initElements(driver,loginpage.class);
	log.signinsecure();
	log.entrmobilenum("surendarkrish10@gmail.com");
	log.cont();
	log.password("8870766744");
	log.signinn();
	
}

public static void main(String[] args) throws InterruptedException   {
		
login s = new login();
s.blankvalues();
s.invalidvalues();
s.loginsuccessful();
	
	}
	
	}

