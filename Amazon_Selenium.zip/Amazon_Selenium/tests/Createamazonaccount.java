package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import pages.loginpage;


	public class Createamazonaccount {
		
		public void blankspace() throws InterruptedException
		
		{
			System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			driver.get("https://www.amazon.in/");
			driver.manage().window().maximize();
			Thread.sleep(5000);	
			loginpage log = PageFactory.initElements(driver,loginpage.class);
			log.signinsecure();
			log.createamazon();
			log.cont();
			
	String a = driver.findElement(By.id("auth-customerName-missing-alert")).getText();
	System.out.println(a);

	String b = driver.findElement(By.id("auth-phoneNumber-missing-alert")).getText();
	System.out.println(b);

	String c = driver.findElement(By.id("auth-password-missing-alert")).getText();
	System.out.println(c);

	Thread.sleep(5000);


		}
		
	public  void entermobilenumber() throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
		Thread.sleep(5000);	
		loginpage log = PageFactory.initElements(driver,loginpage.class);
		log.signinsecure();
		log.createamazon();
		log.mobilenum("text");
		log.cont();
		String g = driver.findElement(By.id("auth-phoneNumber-invalid-phone-alert")).getText();
		System.out.println(g);
		Thread.sleep(5000);
		
		
	}

	public   void passwordlessthan6() throws InterruptedException

	{
		System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
		Thread.sleep(5000);	
		loginpage log = PageFactory.initElements(driver,loginpage.class);
		log.signinsecure();
		log.createamazon();
		log.password("12345");
		log.cont();
		String h = driver.findElement(By.id("auth-password-invalid-password-alert")).getText();
		System.out.println(h);
		Thread.sleep(5000);
		
	}

	public void registrationsuccess() throws InterruptedException
	{
	System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.get("https://www.amazon.in/");
	driver.manage().window().maximize();
	Thread.sleep(5000);	
	loginpage log = PageFactory.initElements(driver,loginpage.class);
	log.signinsecure();
	log.createamazon();
	log.Name("Surendar");
	log.mobilenum("8870766747");
	log.password("Suren10@@@");
	log.cont();
	Thread.sleep(5000);
	System.out.println("The user account is created successfully");


	}
		public static void main(String[] args) throws InterruptedException   {
		Createamazonaccount w = new Createamazonaccount();
		w.blankspace();
		w.entermobilenumber();
		w.passwordlessthan6();
		w.registrationsuccess();

		
		}
		
		}

