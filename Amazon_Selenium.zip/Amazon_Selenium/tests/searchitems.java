package tests;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import pages.loginpage;



public class searchitems {
	
	
	public void login() throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
		Thread.sleep(5000);	
		loginpage log = PageFactory.initElements(driver,loginpage.class);
		log.signinsecure();
		log.entrmobilenum("surendarkrish10@gmail.com");
		log.cont();
		log.password("Suren10!!!");
		log.signinn();
	}

	
public void search5th() throws InterruptedException {
	
	System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.get("https://www.amazon.in/");
	driver.manage().window().maximize();
	Thread.sleep(5000);	
	loginpage log = PageFactory.initElements(driver,loginpage.class);
    log.signinsecure();
	log.entrmobilenum("surendarkrish10@gmail.com");
	log.cont();
	log.password("Suren10!!!");
	log.signinn();
	log.search("mobil");
	Thread.sleep(5000);
	driver.findElement (By.xpath("//*[@id='issDiv4']")).click();
	System.out.println("The 5th element is clicked");
	Thread.sleep(5000);

}


public void moreth500() throws InterruptedException {
	System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.get("https://www.amazon.in/");
	driver.manage().window().maximize();
	Thread.sleep(5000);	
	loginpage log = PageFactory.initElements(driver,loginpage.class);
	log.signinsecure();
	log.entrmobilenum("surendarkrish10@gmail.com");
	log.cont();
	log.password("Suren10@@@");
	log.signinn();
	log.search("watches");
	log.searchclick();
	int n = driver.findElements(By.xpath("//*[@class='a-price-whole']")).size();
	System.out.println(""+n);
Thread.sleep(5000);
int m=500;
	List<WebElement> price = driver.findElements(By.xpath("//*[@class='a-price-whole']"));
for (WebElement element : price)
		
	{   
	
String y = element.getText();
String k = y.replaceAll(",", "");
int z = Integer.parseInt(k);
if (z>=m)
{

System.out.println(z);
System.out.println();

}
}
		
}

public void lessthan500() throws InterruptedException {
	System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.get("https://www.amazon.in/");
	driver.manage().window().maximize();
	Thread.sleep(5000);	
	loginpage log = PageFactory.initElements(driver,loginpage.class);
	log.signinsecure();
	log.entrmobilenum("surendarkrish10@gmail.com");
	log.cont();
	log.password("Welcome123");
	log.signinn();
	log.search("watches");
	log.searchclick();
	int n = driver.findElements(By.xpath("//*[@class='a-price-whole']")).size();
	System.out.println(""+n);
Thread.sleep(5000);
int m=500;
	List<WebElement> price = driver.findElements(By.xpath("//*[@class='a-price-whole']"));
for (WebElement element : price)
		
	{   
	
String y = element.getText();
String k = y.replaceAll(",", "");
int z = Integer.parseInt(k);
if (z<=m)
{

System.out.println(z);
System.out.println();

}
element.click();
	}
}

public void signoutt() throws InterruptedException 

{
	System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
WebDriver driver = new ChromeDriver();
driver.get("https://www.amazon.in/");
driver.manage().window().maximize();
Thread.sleep(5000);	
loginpage log = PageFactory.initElements(driver,loginpage.class);
log.signinsecure();
log.entrmobilenum("surendarkrish10@gmail.com");
log.cont();
log.password("Suren10@@@");
log.signinn();
System.out.println("Player is signed on successfully");
Thread.sleep(5000);
log.signout();
	
}


public void fff() throws InterruptedException

{
	
	System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
WebDriver driver = new ChromeDriver();
driver.get("https://www.amazon.in/s?k=watches+for+women+latest&crid=SEORRXTHFOR8&sprefix=watches%2Caps%2C719&ref=nb_sb_ss_i_5_7");
driver.manage().window().maximize();
boolean  w = driver.getPageSource().contains("sponsoreddd");
System.out.println("vghthth " +w);
Thread.sleep(5000);	
	int n = driver.findElements(By.xpath("//*[@class='a-price-whole']")).size();
	System.out.println(""+n);
Thread.sleep(5000);
int m=500;
	List<WebElement> price = driver.findElements(By.xpath("//*[@class='a-price-whole']"));
for (WebElement element : price)
		
	{   
	
String y = element.getText();
String k = y.replaceAll(",", "");
int z = Integer.parseInt(k);
if (z<=m)
{

System.out.println(z);
System.out.println();
element.click();
Thread.sleep(60000);

Actions action = new Actions(driver);
System.out.println("moved to tab 1");
action.keyDown(Keys.CONTROL).sendKeys(Keys.TAB).build().perform();

WebElement j = driver.findElement(By.name("quantity"));
Select dropdown = new Select(j);
dropdown.selectByValue("2");
driver.findElement(By.id("add-to-cart-button")).click();
break;

	}
}}
	

public void great()

{
	System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
WebDriver driver = new ChromeDriver();
driver.get("http://www.amazon.in");
JavascriptExecutor js = ((JavascriptExecutor)driver);
js.executeScript("window.scrollBy(0,1000)");

}	



public static void main(String[] args) throws InterruptedException {
	
searchitems l = new searchitems();
l.fff();
l.great();
l.signoutt();
l.lessthan500();
l.moreth500();
	}

}
